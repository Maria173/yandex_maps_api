from common.geocoder import get_coordinates
from common.mapapi import show_map
from common.getcoords import get_ll_span

import sys


def main():
    toponym_to_find = " ".join(input())

    if toponym_to_find:
        span = input()
        spn = span + ',' + span
        ll = get_ll_span(toponym_to_find)
        ll_spn = "ll={ll}&spn={spn}".format(**locals())
        point_param = "pt={ll},pmors".format(**locals())
        show_map(ll_spn, "map", add_params=point_param)



    else:
        print('No data')


if __name__ == "__main__":
    main()
